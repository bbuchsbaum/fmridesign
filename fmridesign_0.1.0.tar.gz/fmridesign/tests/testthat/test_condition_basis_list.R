library(testthat)

testthat::local_edition(3)

create_cbl_data <- function() {
  event_data <- data.frame(
    onset = c(0, 30, 60),
    cond  = factor(c("A", "B", "A")),
    run   = 1
  )
  sframe <- fmrihrf::sampling_frame(blocklens = 90, TR = 1)
  emod <- event_model(onset ~ hrf(cond), data = event_data,
                      block = ~run, sampling_frame = sframe)
  list(term = emod$terms[[1]], sframe = sframe)
}

test_that("condition_basis_list splits matrix by condition", {
  dat <- create_cbl_data()
  term <- dat$term
  sf   <- dat$sframe

  res <- condition_basis_list(term, fmrihrf::HRF_SPMG2, sf)

  expect_type(res, "list")
  expect_equal(length(res), 2)
  expect_named(res, c("cond.A", "cond.B"))

  nb <- fmrihrf::nbasis(fmrihrf::HRF_SPMG2)
  expect_true(all(vapply(res, ncol, integer(1)) == nb))
  expect_true(all(vapply(res, nrow, integer(1)) == sum(fmrihrf::blocklens(sf))))
})

test_that("condition_basis_list matrix output matches convolve", {
  dat <- create_cbl_data()
  term <- dat$term
  sf   <- dat$sframe

  mat1 <- condition_basis_list(term, fmrihrf::HRF_SPMG2, sf, output = "matrix")
  mat2 <- convolve(term, hrf = fmrihrf::HRF_SPMG2, sampling_frame = sf)

  expect_equal(mat1, mat2)
})

test_that("condition_basis_list handles multi-basis FIR HRF", {
  dat <- create_cbl_data()
  term <- dat$term
  sf   <- dat$sframe

  fir_hrf <- fmrihrf::HRF_FIR
  res <- condition_basis_list(term, fir_hrf, sf)

  expect_type(res, "list")
  expect_equal(length(res), 2)
  expect_named(res, c("cond.A", "cond.B"))

  nb <- fmrihrf::nbasis(fir_hrf)
  expect_true(all(vapply(res, ncol, integer(1)) == nb))

  dm <- convolve(term, hrf = fir_hrf, sampling_frame = sf)
  term_tag <- attr(term, "term_tag")
  if (is.null(term_tag) && nzchar(term$varname)) {
    term_tag <- sanitize(term$varname, allow_dot = FALSE)
  }

  for (cond_name in names(res)) {
    expected_cols <- fmridesign:::make_column_names(term_tag, cond_name, nb)
    expect_equal(res[[cond_name]], dm[, expected_cols, drop = FALSE])
  }
})
