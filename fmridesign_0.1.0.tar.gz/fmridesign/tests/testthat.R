library(testthat)
library(fmridesign)

test_check("fmridesign")